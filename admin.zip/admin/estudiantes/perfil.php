<?php
declare(strict_types=1);
require_once __DIR__ . '/../../includes/seguridad.php';
exigirAdmin();
function h($v):string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function fotoPerfil(?string $foto):string{ $foto=trim((string)$foto); if($foto==='')return ''; if(preg_match('#^https?://#i',$foto))return $foto; $foto=str_replace('\\','/',ltrim($foto,'/')); if(str_starts_with($foto,'assets/'))return urlAplicacion('/'.$foto); if(str_starts_with($foto,'uploads/'))return urlAplicacion('/assets/'.$foto); return urlAplicacion('/assets/uploads/avatares/'.basename($foto)); }
$id=filter_input(INPUT_GET,'id',FILTER_VALIDATE_INT);if(!$id){header('Location: index.php');exit;}
try{
$st=$conexion->prepare("SELECT u.id_usuario,u.nombres,u.apellidos,u.correo,u.grado,u.numero_documento,u.avatar,u.puntos,u.nivel,u.estado,u.fecha_registro,u.ultimo_acceso,c.grupo FROM usuarios u LEFT JOIN cursos c ON c.id_curso=u.id_curso WHERE u.id_usuario=? AND u.id_rol=2 LIMIT 1");$st->execute([$id]);$est=$st->fetch(PDO::FETCH_ASSOC);if(!$est){header('Location: index.php');exit;}
$st=$conexion->prepare("SELECT n.nombre AS nivel_nombre,n.puntos_minimos,n.puntos_maximos FROM niveles n WHERE n.id_nivel=? LIMIT 1");$st->execute([(int)$est['nivel']]);$nivel=$st->fetch(PDO::FETCH_ASSOC)?:[];
$st=$conexion->prepare("SELECT i.nombre,i.descripcion,ui.fecha FROM usuarios_insignias ui INNER JOIN insignias i ON i.id_insignia=ui.id_insignia WHERE ui.id_usuario=? AND i.estado='Activa' ORDER BY ui.fecha DESC");$st->execute([$id]);$insignias=$st->fetchAll(PDO::FETCH_ASSOC);
$st=$conexion->prepare("SELECT m.nombre,COUNT(t.id_tema) total_temas,COALESCE(SUM(CASE WHEN p.completado=1 OR p.porcentaje_avance>=100 THEN 1 ELSE 0 END),0) completados,COALESCE(AVG(p.porcentaje_avance),0) promedio FROM materias m INNER JOIN temas t ON t.id_materia=m.id_materia AND t.grado=? LEFT JOIN progreso p ON p.id_tema=t.id_tema AND p.id_usuario=? GROUP BY m.id_materia,m.nombre ORDER BY m.nombre");$st->execute([$est['grado'],$id]);$progreso=$st->fetchAll(PDO::FETCH_ASSOC);
} catch(Throwable $e){die('No fue posible cargar el perfil del estudiante.');}
$foto=fotoPerfil($est['avatar']??'');$nombre=trim($est['nombres'].' '.$est['apellidos']);$iniciales='';foreach(preg_split('/\s+/',trim($nombre)) as $parte){if($parte!=='')$iniciales.=mb_strtoupper(mb_substr($parte,0,1));if(mb_strlen($iniciales)>=2)break;}
?>
<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Perfil de estudiante | Studia360</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css"><style>
:root{--blue:#2563eb;--navy:#173f78;--bg:#f6f8fc;--border:#e4eaf2;--muted:#718096;--text:#23344b}body{background:radial-gradient(circle at top right,#eaf2ff,transparent 28%),var(--bg);color:var(--text);font-family:Inter,system-ui,-apple-system,"Segoe UI",sans-serif}.top{background:linear-gradient(105deg,#173f78,#2563b8)}.shell{max-width:1150px;margin:auto;padding:32px 16px 60px}.hero{border-radius:27px;padding:28px;color:#fff;background:linear-gradient(125deg,#2563b8,#173f78);box-shadow:0 18px 42px rgba(23,63,120,.16)}.cardx{background:#fff;border:1px solid var(--border);border-radius:22px;box-shadow:0 10px 28px rgba(31,57,92,.055)}.photo{width:150px;height:150px;border-radius:38px;object-fit:cover;border:5px solid #fff;box-shadow:0 10px 30px rgba(0,0,0,.12);background:#eaf2ff}.placeholder{width:150px;height:150px;border-radius:38px;background:#eaf2ff;color:var(--blue);display:flex;align-items:center;justify-content:center;font-size:3rem;font-weight:900;border:5px solid #fff}.badge-title{display:inline-flex;align-items:center;gap:7px;border:1px solid #ead9a0;background:#fff9df;color:#8a6814;border-radius:999px;padding:7px 12px;font-weight:800;font-size:.82rem}.progress{height:9px;background:#edf1f6}.progress-bar{background:linear-gradient(90deg,#2563eb,#66a0ef)}.muted{color:var(--muted)}.kv{border:1px solid var(--border);border-radius:15px;padding:13px;background:#fbfcfe}
</style>    <link rel="stylesheet" href="estudiantes.css">

<link rel="stylesheet" href="<?= htmlspecialchars(urlAplicacion('/admin/assets/studia-admin.css'), ENT_QUOTES, 'UTF-8') ?>">

<style id="studia360-local-theme-fix">
body.adm-dark,body.s360-content-dark{background:#0d1424!important;color:#edf2f8!important}
body.adm-dark .cardx,body.adm-dark .kv,body.s360-content-dark .cardx,body.s360-content-dark .kv,body.s360-content-dark .materia-card{background:#172236!important;color:#edf2f8!important;border-color:#2b374b!important}
body.adm-dark .kv strong,body.adm-dark .cardx h2,body.s360-content-dark .cardx h2,body.s360-content-dark .materia-card h2,body.s360-content-dark .materia-card p{color:#edf2f8!important}
body.adm-dark .muted,body.adm-dark .text-muted,body.s360-content-dark .muted,body.s360-content-dark .s360-muted,body.s360-content-dark .text-muted{color:#9ba8ba!important}
body.adm-dark .progress,body.s360-content-dark .progress{background:#263449!important}
body.adm-dark .photo,body.adm-dark .placeholder{border-color:#2b374b!important}
body.adm-dark .placeholder{background:#202c41!important}
body.adm-dark .alert-light{background:#111a2b!important;color:#edf2f8!important;border-color:#334158!important}
body.s360-content-theme .materia-card{background:var(--s360card,#fff)!important;color:var(--s360text,#1f2937)!important;border-color:var(--s360line,#e5eaf1)!important}
body.s360-content-theme .materia-card h2,body.s360-content-theme .materia-card p{color:var(--s360text,#1f2937)!important}
body.s360-content-theme.s360-content-dark .materia-card h2,body.s360-content-theme.s360-content-dark .materia-card p{color:#edf2f8!important}
body.s360-content-theme .materia-icon{background:var(--s360soft,#eff6ff)!important;color:var(--s360a,#2563eb)!important}
body.s360-content-theme .topic-pill{background:var(--s360soft,#eff6ff)!important;color:var(--s360a,#2563eb)!important;border-color:var(--s360line,#e5eaf1)!important}
body.s360-content-theme.s360-content-dark .topic-pill{background:#202c41!important;color:#cbd5e1!important;border-color:#334158!important}
body.s360-content-theme.s360-content-dark .btn-light{background:#172236!important;color:#edf2f8!important;border-color:#334158!important}
body.s360-content-theme.s360-content-dark .btn-outline-secondary{background:transparent!important;color:#b8c2d0!important;border-color:#46536a!important}
body.s360-content-theme.s360-content-dark .btn-outline-danger{color:#ff8f9d!important;border-color:#a33b4b!important}
body.s360-content-theme.s360-content-dark .modal-content{background:#172236!important;color:#edf2f8!important;border-color:#334158!important}
body.s360-content-theme.s360-content-dark .modal-header,body.s360-content-theme.s360-content-dark .modal-footer{border-color:#2b374b!important}
body.s360-content-theme.s360-content-dark .modal .form-control{background:#111827!important;color:#edf2f8!important;border-color:#334158!important}
body.s360-content-theme.s360-content-dark .modal .form-control::placeholder{color:#7f8ca1!important}
body.s360-content-theme.s360-content-dark .btn-close{filter:invert(1) grayscale(1) brightness(2)}
body.adm-dark .adm-theme-panel,body.s360-content-theme.s360-content-dark .adm-theme-panel{background:#172236!important;color:#edf2f8!important;border-color:#334158!important}
body.adm-dark .adm-theme-option,body.adm-dark .adm-mode-btn,body.s360-content-theme.s360-content-dark .adm-theme-option,body.s360-content-theme.s360-content-dark .adm-mode-btn{background:#111a2b!important;color:#edf2f8!important;border-color:#334158!important}
</style>

</head><body class="s360-admin"><nav class="navbar navbar-studia">
<div class="container-fluid px-3 px-lg-4 py-2">
<a class="navbar-brand fw-bold" href="<?=h(urlAplicacion('/admin/dashboard.php'))?>"><span class="brand-mark"><i class="bi bi-stars"></i></span>Studia360</a>
<div class="d-flex align-items-center gap-2">
<div class="dropdown">
<button class="btn btn-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false"><i class="bi bi-grid-3x3-gap me-1"></i> Gestión</button>
<ul class="dropdown-menu dropdown-menu-end shadow-sm border-0 p-2" style="border-radius:14px">
<li><a class="dropdown-item rounded-2 small" href="index.php"><i class="bi bi-people me-2"></i>Estudiantes</a></li>
<li><a class="dropdown-item rounded-2 small" href="../dashboard.php"><i class="bi bi-speedometer2 me-2"></i>Dashboard</a></li>
</ul>
</div>
<a class="btn btn-outline-light btn-sm" href="index.php"><i class="bi bi-arrow-left me-1"></i><span class="d-none d-sm-inline">Estudiantes</span></a>
<a class="btn btn-outline-light btn-sm" href="<?=h(urlAplicacion('/cerrar_sesion.php'))?>"><i class="bi bi-box-arrow-right me-1"></i><span class="d-none d-sm-inline">Salir</span></a>
</div>
</div>
</nav>
<main class="shell"><section class="hero mb-4"><div class="row align-items-center g-4"><div class="col-auto"><?php if($foto):?><img class="photo" src="<?=h($foto)?>" alt="Foto de <?=h($nombre)?>"><?php else:?><div class="placeholder"><?=h($iniciales?:'ES')?></div><?php endif;?></div><div class="col"><div class="small text-uppercase fw-bold opacity-75">Perfil del estudiante</div><h1 class="h2 fw-bold mb-2"><?=h($nombre)?></h1><div class="d-flex flex-wrap gap-2"><span class="badge rounded-pill text-bg-light text-primary">Grado <?=h($est['grado'])?>°<?php if(!empty($est['grupo'])):?> · <?=h($est['grupo'])?><?php endif;?></span><span class="badge rounded-pill text-bg-light text-primary">Nivel <?=h($est['nivel'])?> · <?=h($nivel['nivel_nombre']??'Sin nivel')?></span><span class="badge rounded-pill text-bg-light text-primary"><?=number_format((int)$est['puntos'])?> XP</span></div></div></div></section>
<div class="row g-4"><div class="col-lg-5"><section class="cardx p-4 mb-4"><h2 class="h5 fw-bold mb-3"><i class="bi bi-person-vcard me-2 text-primary"></i>Información</h2><div class="d-grid gap-2"><div class="kv"><small class="muted d-block">Correo</small><strong><?=h($est['correo'])?></strong></div><div class="kv"><small class="muted d-block">Número de documento</small><strong><?=h($est['numero_documento'])?></strong></div><div class="kv"><small class="muted d-block">Estado de cuenta</small><strong class="<?=$est['estado']==='Activo'?'text-success':'text-danger'?>"><?=h($est['estado'])?></strong></div><div class="kv"><small class="muted d-block">Último acceso</small><strong><?=h($est['ultimo_acceso']?:'Sin registro')?></strong></div></div></section><section class="cardx p-4"><h2 class="h5 fw-bold mb-2"><i class="bi bi-award me-2 text-primary"></i>Emblemas obtenidos</h2><p class="muted small">Estos títulos representan las materias que el estudiante ha completado.</p><?php if(!$insignias):?><div class="text-center py-3 muted"><i class="bi bi-award display-6 d-block mb-2"></i>Aún no tiene emblemas.</div><?php else:?><div class="d-flex flex-wrap gap-2"><?php foreach($insignias as $i):?><span class="badge-title"><i class="bi bi-patch-check-fill"></i><?=h($i['nombre'])?></span><?php endforeach;?></div><?php endif;?></section></div><div class="col-lg-7"><section class="cardx p-4"><h2 class="h5 fw-bold mb-1"><i class="bi bi-graph-up-arrow me-2 text-primary"></i>Progreso académico</h2><p class="muted small mb-4">Avance del estudiante según los temas correspondientes a su grado.</p><?php if(!$progreso):?><div class="muted">No hay temas configurados para este grado.</div><?php else:?><?php foreach($progreso as $p):$total=(int)$p['total_temas'];$comp=(int)$p['completados'];$pct=$total>0?min(100,round($comp/$total*100)):0;?><div class="mb-4"><div class="d-flex justify-content-between mb-2"><strong><?=h($p['nombre'])?></strong><span class="small muted"><?=$comp?>/<?=$total?> temas · <?=$pct?>%</span></div><div class="progress"><div class="progress-bar" style="width:<?=$pct?>%"></div></div></div><?php endforeach;?><?php endif;?></section></div></div></main><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<!-- Studia360 Admin: personalizador global -->
<button id="admThemeToggle" class="adm-theme-toggle" type="button" aria-label="Personalizar apariencia" title="Personalizar apariencia"><i class="bi bi-palette2"></i></button>
<div id="admThemePanel" class="adm-theme-panel" aria-label="Personalizar apariencia">
<div class="adm-theme-title">Personaliza el panel</div><div class="adm-theme-sub">Elige un color y usa el modo claro u oscuro en todo el administrador.</div>
<div class="adm-theme-grid">
<button class="adm-theme-option" data-theme="purple" type="button" onclick="admSetTheme('purple')"><div class="adm-swatch" style="background:linear-gradient(135deg,#8b5cf6,#7c3aed)"></div><strong>Violeta</strong><small>Studia360</small></button>
<button class="adm-theme-option" data-theme="blue" type="button" onclick="admSetTheme('blue')"><div class="adm-swatch" style="background:linear-gradient(135deg,#2563eb,#4f46e5)"></div><strong>Azul</strong><small>Clásico</small></button>
<button class="adm-theme-option" data-theme="orange" type="button" onclick="admSetTheme('orange')"><div class="adm-swatch" style="background:linear-gradient(135deg,#f97316,#ea580c)"></div><strong>Naranja</strong><small>Enérgico</small></button>
<button class="adm-theme-option" data-theme="green" type="button" onclick="admSetTheme('green')"><div class="adm-swatch" style="background:linear-gradient(135deg,#10b981,#059669)"></div><strong>Verde</strong><small>Calma</small></button>
</div><button id="admModeBtn" class="adm-mode-btn" type="button" onclick="admToggleMode()"></button></div>

<script id="studia360-theme-controller">
(function(){
'use strict';
var body=document.body,key='studia360_theme',legacy='studia360_admin_theme';
var themes={blue:'',orange:'s360-accent-orange',purple:'s360-accent-purple',green:'s360-accent-green'};
var saved={theme:'blue',mode:'light'};
try{var raw=localStorage.getItem(key)||localStorage.getItem(legacy);if(raw){var p=JSON.parse(raw);if(p&&typeof p==='object'){if(typeof p.theme==='string')saved.theme=p.theme;if(p.mode==='dark'||p.mode==='light')saved.mode=p.mode;}}}catch(e){}
if(!Object.prototype.hasOwnProperty.call(themes,saved.theme))saved.theme='blue';
function save(){try{localStorage.setItem(key,JSON.stringify(saved));localStorage.setItem(legacy,JSON.stringify(saved));}catch(e){}}
function apply(){
Object.keys(themes).forEach(function(k){if(themes[k])body.classList.remove(themes[k]);});
body.classList.add('s360-content-theme');
if(themes[saved.theme])body.classList.add(themes[saved.theme]);
body.classList.toggle('s360-content-dark',saved.mode==='dark');
body.classList.toggle('adm-dark',saved.mode==='dark');
document.querySelectorAll('.adm-theme-option').forEach(function(x){x.classList.toggle('active',x.getAttribute('data-theme')===saved.theme);});
var mode=document.getElementById('admModeBtn');if(mode)mode.innerHTML=saved.mode==='dark'?'<i class="bi bi-moon-stars me-2"></i>Modo oscuro':'<i class="bi bi-sun me-2"></i>Modo claro';
}
window.admSetTheme=function(x){if(!Object.prototype.hasOwnProperty.call(themes,x))return;saved.theme=x;save();apply()};
window.admToggleMode=function(){saved.mode=saved.mode==='dark'?'light':'dark';save();apply()};
apply();
var toggle=document.getElementById('admThemeToggle'),panel=document.getElementById('admThemePanel');
if(toggle)toggle.addEventListener('click',function(e){e.preventDefault();e.stopPropagation();if(panel)panel.classList.toggle('open')});
if(panel)panel.addEventListener('click',function(e){e.stopPropagation()});
document.addEventListener('click',function(e){if(panel&&toggle&&!panel.contains(e.target)&&!toggle.contains(e.target))panel.classList.remove('open')});
})();
</script>

</body></html>
